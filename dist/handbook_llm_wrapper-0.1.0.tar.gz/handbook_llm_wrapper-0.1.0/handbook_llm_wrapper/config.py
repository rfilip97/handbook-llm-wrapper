REPO_URL = "git@github.com:Agilefreaks/handbook.git"
TMP_HANDBOOK_PATH = "./tmp/handbook_repo"
TMP_DATA_SOURCE_PATH = "./tmp/data_source"

CHUNK_SIZE = 400
CHUNK_OVERLAP = 60
TOP_P = 0.25
TEMPERATURE = 0
MAX_TOKENS = 2000
